export class TipoDto {
  id: number;
  nome: string;
}
