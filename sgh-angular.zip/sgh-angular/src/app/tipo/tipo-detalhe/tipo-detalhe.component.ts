import { Component, OnInit } from '@angular/core';
import {TipoService} from '../tipo.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {TipoDto} from '../../model/tipo-dto';

@Component({
  selector: 'app-tipo-detalhe',
  templateUrl: './tipo-detalhe.component.html',
  styleUrls: ['./tipo-detalhe.component.css']
})
export class TipoDetalheComponent implements OnInit {

  constructor(
    private tipoService: TipoService,
    private fb: FormBuilder
  ) { }
  formTipo: FormGroup;
  tipo: TipoDto;
  ngOnInit(): void {
    this.formTipo = this.fb.group({
      id: [this.tipo.id],
      nome: [this.tipo.nome, [Validators.required, Validators.minLength(3)]]
    });
  }

  onSubmit(): void{

  }
  // tslint:disable-next-line:typedef
  isFieldInvalid(field: string) {
    return(
      (!this.formTipo.get(field).valid && this.formTipo.get(field).touched) ||
      (this.formTipo.get(field).untouched) || (this.formTipo.get(field).errors)
    );
  }

}
