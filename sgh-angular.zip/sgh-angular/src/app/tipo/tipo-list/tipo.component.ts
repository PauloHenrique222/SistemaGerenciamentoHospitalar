import { Component, OnInit } from '@angular/core';
import { TipoService } from '../tipo.service';
import { TipoDto } from '../../model/tipo-dto';

@Component({
  selector: 'app-tipo',
  templateUrl: './tipo.component.html',
  styleUrls: ['./tipo.component.css']
})

export class TipoComponent implements OnInit {
  constructor(
    private tipoService: TipoService
  ) { }
  displayedColumns: string[] = ['id', 'nome'];
  tipos: TipoDto[];
  dataSource;
  tipo: TipoDto = { id: undefined, nome: 'Unidade Básica de Saúde'};
  ngOnInit(): void {
    this.tipoService.list().subscribe(dados => {
      this.tipos = dados;
      this.dataSource = this.tipos;
    });
  }
  salvar(): void{
    this.tipoService.save(this.tipo).subscribe((dado) => {
      this.tipoService.showMessage('Tipo salvo com sucesso!', false);
      this.tipos.push(dado);
      this.dataSource = this.tipos;
      location.reload();
    });
  }
}

