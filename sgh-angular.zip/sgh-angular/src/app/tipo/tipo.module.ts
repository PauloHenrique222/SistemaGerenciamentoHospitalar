import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TipoComponent } from './tipo-list/tipo.component';
import { MatTableModule } from '@angular/material/table';
import {MatButtonModule} from '@angular/material/button';
import { TipoDetalheComponent } from './tipo-detalhe/tipo-detalhe.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import {ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [TipoComponent, TipoDetalheComponent],
  exports: [
    TipoComponent,
    TipoDetalheComponent
  ],
  imports: [
    CommonModule,
    MatTableModule,
    MatButtonModule,
    MatFormFieldModule,
    ReactiveFormsModule
  ]
})
export class TipoModule { }
