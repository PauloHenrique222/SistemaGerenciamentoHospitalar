import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {TipoDto} from '../model/tipo-dto';
import {EMPTY, Observable, Subscription} from 'rxjs';
import {catchError, map} from 'rxjs/operators';
import {environment} from '../../environments/environment';
import {MatSnackBar} from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class TipoService {

  constructor(
    private httpClient: HttpClient,
    private snackBar: MatSnackBar
  ) { }
  url = `${environment.config.URL_API}`;
  list(): Observable<TipoDto[]> {
    return this.httpClient.get<TipoDto[]>(`${this.url}/tipos`).pipe(
      map((tipos) => tipos)
    );
  }

  save(tipo: TipoDto): Observable<TipoDto>{
    return this.httpClient.post<TipoDto>(`${this.url}/tipos/create`, tipo).pipe(
      map((obj) => obj),
      catchError((e) => this.errorHandler(e))
    );
  }

  update(tipo: TipoDto): Observable<TipoDto>{
    return this.httpClient.post<TipoDto>(`${this.url}/tipos/edit`, tipo).pipe(
      map((obj) => obj),
      catchError((e) => this.errorHandler(e))
    );
  }

  errorHandler(e: any): Observable<any>{
    this.showMessage('Ocorreu um erro', true);
    return EMPTY;
  }

  showMessage(msg: string, isError: boolean = false): void{
    this.snackBar.open(msg, 'x', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
      panelClass: isError ? ['msg:error'] : ['msg-success']
    });
  }
}
